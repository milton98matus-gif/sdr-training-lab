'use strict';
const ONBOARDING={
  "UNITS": [
    {
      "id": "companies",
      "phase": "orientation",
      "title": "Welcome to OSR & GSD",
      "subtitle": "Understand the organizations behind your work.",
      "cards": [
        {
          "title": "OSR Manage",
          "body": "Osprey Strategic Research (OSR) helps Managed Service Providers (MSPs) and channel partners build and improve sales through recruiting, training, sales management, coaching, and sales processes. Its work supports the people and systems that grow an MSP’s business."
        },
        {
          "title": "GSD Staffing",
          "body": "Global Service Delivery (GSD) Staffing connects U.S. and Canadian businesses with vetted professionals in Latin America. Roles include virtual assistance, technical support, marketing, and sales operations. Nearshore collaboration supports teams working in similar time zones."
        },
        {
          "title": "How the pieces connect",
          "body": "OSR and GSD are sister companies in this onboarding context. A client MSP delivers IT services to its customers. Your assigned campaign determines which MSP you represent and what you can offer. Confirm your actual reporting line and account instructions with your manager; this overview does not define employment policies."
        }
      ],
      "scene": "You join a campaign for a regional MSP. A prospect asks whether your company recruits employees or manages their IT.",
      "questions": [
        {
          "prompt": "What should guide your introduction on an assigned MSP campaign?",
          "options": [
            {
              "text": "The assigned MSP’s approved identity and offer.",
              "why": "Represent the actual service provider and purpose of this campaign."
            },
            {
              "text": "Describe every OSR and GSD service on every call.",
              "why": "A corporate overview does not replace a relevant campaign introduction."
            },
            {
              "text": "Introduce GSD as the prospect’s outsourced IT provider.",
              "why": "Staffing and the assigned MSP’s service delivery are different roles."
            }
          ],
          "answer": 0
        },
        {
          "prompt": "Which pairing is accurate?",
          "options": [
            {
              "text": "OSR: antivirus vendor. GSD: cloud platform.",
              "why": "Neither description represents the companies’ core offers."
            },
            {
              "text": "Every client MSP sells the same services as OSR.",
              "why": "An MSP’s IT portfolio is different from OSR’s sales-management work."
            },
            {
              "text": "OSR: sales management and development. GSD: nearshore staffing.",
              "why": "This keeps the overview simple and grounded in each company’s public services."
            }
          ],
          "answer": 2
        }
      ],
      "terms": []
    },
    {
      "id": "sdr-role",
      "phase": "orientation",
      "title": "Your job on the call",
      "subtitle": "Create a useful next step from a real opening.",
      "cards": [
        {
          "title": "The SDR outcome",
          "body": "As a Sales Development Representative (SDR), your goal is a relevant discovery appointment when the contact is receptive and there is a credible reason to talk. Routing, an agreed callback, a limited email handoff, or a respectful exit can also be the right next step."
        },
        {
          "title": "Your lane",
          "body": "Describe approved general services, understand the current setup, explore business impact, and agree what happens next. Specialists handle solution design, detailed technical validation, scope, and pricing. Do not improvise a quote or diagnose a system."
        },
        {
          "title": "A useful daily rhythm",
          "body": "Review your assigned MSP brief, practice a focused skill, complete the assigned exercises, and record uncertainties. Submit work as you go. A learning record shows decisions and explanations; it does not measure background attendance or replace live-call supervision."
        }
      ],
      "scene": "A contact asks how much a managed IT plan costs before explaining their environment.",
      "questions": [
        {
          "prompt": "What is an appropriate response?",
          "options": [
            {
              "text": "Invent a typical per-user price to keep interest.",
              "why": "An unapproved estimate sets a false expectation."
            },
            {
              "text": "Demand a calendar commitment before saying anything else.",
              "why": "The contact still needs a clear purpose and freedom to decline."
            },
            {
              "text": "Explain that scope and plans are discussed by the right person after discovery; ask a relevant setup question if welcome.",
              "why": "You can clarify the process and explore fit without quoting or forcing an appointment."
            }
          ],
          "answer": 2
        },
        {
          "prompt": "Which outcome can show sound SDR judgment?",
          "options": [
            {
              "text": "Marking a forwarded message as a confirmed discovery call.",
              "why": "Forwarding is not decision-maker acceptance."
            },
            {
              "text": "Confirming the right corporate contact route when a local office cannot decide.",
              "why": "A reliable route can be the available opportunity."
            },
            {
              "text": "Booking a meeting after a repeated firm refusal.",
              "why": "A calendar entry obtained through pressure is not a sound next step."
            }
          ],
          "answer": 1
        }
      ],
      "terms": []
    },
    {
      "id": "msp-model",
      "phase": "foundations",
      "title": "What an MSP actually does",
      "subtitle": "Understand ongoing IT ownership and service models.",
      "cards": [
        {
          "title": "Managed Service Provider",
          "body": "A Managed Service Provider (MSP) provides ongoing management and support for agreed parts of a customer’s technology. That can include people’s devices, business systems, networks, cloud services, and security. The agreement defines responsibilities, service hours, exclusions, and how work is requested."
        },
        {
          "title": "Fully managed, co-managed, break/fix",
          "body": "Fully managed IT outsources an agreed set of ongoing responsibilities. Co-managed IT shares responsibilities with an internal team. Break/fix is reactive help when something fails. Project work has a defined deliverable, such as a migration. These models can coexist; names alone do not establish scope."
        },
        {
          "title": "Tools support delivery",
          "body": "Remote Monitoring and Management (RMM) helps a provider monitor and manage devices remotely. A Professional Services Automation (PSA) platform helps organize service work, tickets, and related business processes. Owning a tool or license is different from assigning people to monitor, respond, escalate, and follow through."
        }
      ],
      "scene": "“We already have someone who fixes computers, and our office manager calls them when something breaks.”",
      "questions": [
        {
          "prompt": "What is still useful to understand?",
          "options": [
            {
              "text": "Which exact replacement plan they must buy.",
              "why": "The current setup and fit have not been established."
            },
            {
              "text": "How ongoing maintenance and day-to-day support are handled between incidents.",
              "why": "Explore the operating model without criticizing a trusted technician."
            },
            {
              "text": "Whether their technician is incompetent.",
              "why": "There is no evidence to make that accusation."
            }
          ],
          "answer": 1
        },
        {
          "prompt": "What does co-managed IT mean?",
          "options": [
            {
              "text": "An agreed division of responsibilities with an internal IT team.",
              "why": "Scope and ownership matter more than the label."
            },
            {
              "text": "The MSP automatically replaces the IT manager.",
              "why": "Co-management does not inherently mean staff replacement."
            },
            {
              "text": "The customer gives up all business responsibility for IT.",
              "why": "A service agreement does not erase customer decisions and responsibilities."
            }
          ],
          "answer": 0
        }
      ],
      "terms": [
        "msp",
        "co-managed-it",
        "break-fix"
      ]
    },
    {
      "id": "service-map",
      "phase": "foundations",
      "title": "The MSP service map",
      "subtitle": "Look beyond cybersecurity.",
      "cards": [
        {
          "title": "Support and infrastructure",
          "body": "Common service areas include help desk, employee onboarding and offboarding, device management, servers, networks, connectivity coordination, and vendor management. An MSP may resolve work directly or coordinate with an internet provider or software vendor."
        },
        {
          "title": "Cloud, continuity, and protection",
          "body": "An MSP may manage Microsoft 365 or other cloud environments, permissions, migrations, backups, recovery planning, and security services. Cloud hosting, a software license, and ongoing administration are separate responsibilities."
        },
        {
          "title": "Planning and change",
          "body": "Some MSPs provide technology roadmaps, budgeting support, lifecycle planning, projects, or strategic guidance such as Virtual Chief Information Officer (vCIO) services. Do not assume every MSP offers everything on this map. Use your assigned brief to confirm the actual portfolio."
        }
      ],
      "scene": "“We’re not shopping for cybersecurity. We need our new employees productive faster.”",
      "questions": [
        {
          "prompt": "Which topic is most relevant?",
          "options": [
            {
              "text": "How devices, accounts, access, and onboarding requests are coordinated.",
              "why": "The stated need is operational onboarding, not a security pitch."
            },
            {
              "text": "Repeat the ransomware message until they engage.",
              "why": "That ignores the business need they just provided."
            },
            {
              "text": "Promise you can supply any HR staffing role.",
              "why": "Employee IT onboarding is different from an unverified staffing offer."
            }
          ],
          "answer": 0
        },
        {
          "prompt": "What should you do before promising a service?",
          "options": [
            {
              "text": "Assume all MSPs include all cloud and security services.",
              "why": "Service portfolios and agreements vary."
            },
            {
              "text": "Promise it now and let discovery correct it later.",
              "why": "A discovery call should not have to repair an invented offer."
            },
            {
              "text": "Check that the assigned MSP offers it and understand the approved scope.",
              "why": "A broad industry portfolio is not a client-specific commitment."
            }
          ],
          "answer": 2
        }
      ],
      "terms": []
    },
    {
      "id": "support-delivery",
      "phase": "foundations",
      "title": "How support gets delivered",
      "subtitle": "Tickets, priority, escalation, and accountability.",
      "cards": [
        {
          "title": "The service journey",
          "body": "A user reports an issue through an approved channel. The team records a ticket, assesses urgency and business impact, assigns ownership, works the issue, escalates when needed, and confirms the result. A major office outage and one user’s low-priority request need different handling."
        },
        {
          "title": "Response is not resolution",
          "body": "A Service Level Agreement (SLA) defines service commitments in an agreement. A response target means acknowledgment or the agreed initial action; it is not automatically a fixed-time repair. Ask how issues are handled today without promising a resolution time."
        },
        {
          "title": "Coverage has several meanings",
          "body": "Monitoring can run continuously while live help desk availability is limited to contracted hours. After-hours support may have eligibility or escalation conditions. The MSP manages its staffing and agreed execution; the customer still approves business priorities, budgets, and access."
        }
      ],
      "scene": "“We have 24/7 monitoring, but when someone cannot log in at night, we wait until morning.”",
      "questions": [
        {
          "prompt": "What distinction matters?",
          "options": [
            {
              "text": "24/7 monitoring guarantees every issue is fixed immediately.",
              "why": "Monitoring does not establish that commitment."
            },
            {
              "text": "The provider must be lying.",
              "why": "The agreement and actual coverage have not been inspected."
            },
            {
              "text": "Monitoring coverage and live user-support coverage may differ.",
              "why": "Clarify who responds, to what, and during which hours."
            }
          ],
          "answer": 2
        },
        {
          "prompt": "An SLA promises a response within an agreed window. What can you safely conclude?",
          "options": [
            {
              "text": "The client has no role in any escalation.",
              "why": "Customer decisions and cooperation can still matter."
            },
            {
              "text": "The defined initial response is time-bound; resolution depends on the agreement and issue.",
              "why": "Do not turn a response target into a repair guarantee."
            },
            {
              "text": "Every issue will be resolved within that response window.",
              "why": "Response and resolution are different."
            }
          ],
          "answer": 1
        }
      ],
      "terms": [
        "sla",
        "help-desk"
      ]
    },
    {
      "id": "devices-networks",
      "phase": "foundations",
      "title": "Devices, networks, and everyday friction",
      "subtitle": "Recognize the service area without diagnosing.",
      "cards": [
        {
          "title": "Endpoints",
          "body": "Laptops, desktops, and mobile devices are endpoints. Managing them can include setup, updates, access configuration, troubleshooting, and lifecycle replacement. A new hire waiting for a laptop is a business problem as well as an IT task."
        },
        {
          "title": "Networks and connectivity",
          "body": "Office Wi-Fi, switches, firewalls, internet connections, and remote access connect people to applications. A slow application could have many causes. An SDR should explore who is affected, how often, and what work is interrupted, rather than declare the root cause."
        },
        {
          "title": "Vendor coordination",
          "body": "The MSP may coordinate with internet, software, and hardware providers within its scope. A clear owner can reduce the customer’s coordination burden. That does not mean the MSP controls every third-party outage or can guarantee its repair time."
        }
      ],
      "scene": "“Our booking system freezes twice a week, and everyone blames someone else.”",
      "questions": [
        {
          "prompt": "Which question adds useful discovery?",
          "options": [
            {
              "text": "Would you replace your whole network tomorrow?",
              "why": "A replacement project is premature."
            },
            {
              "text": "When it freezes, who is affected and who owns getting it resolved?",
              "why": "This establishes impact and service ownership without diagnosing."
            },
            {
              "text": "Is your firewall definitely outdated?",
              "why": "The symptom does not establish a firewall cause."
            }
          ],
          "answer": 1
        },
        {
          "prompt": "Which value statement fits the evidence?",
          "options": [
            {
              "text": "A discovery conversation could explore clearer ownership across the vendors involved.",
              "why": "This connects the offer to the coordination problem."
            },
            {
              "text": "Our MSP can prevent all software outages.",
              "why": "No such outcome is established or supportable."
            },
            {
              "text": "We will eliminate all of your vendors.",
              "why": "Coordination does not require replacing every vendor."
            }
          ],
          "answer": 0
        }
      ],
      "terms": []
    },
    {
      "id": "cloud",
      "phase": "foundations",
      "title": "Cloud and Microsoft 365 basics",
      "subtitle": "Licenses, administration, identity, and change.",
      "cards": [
        {
          "title": "Cloud in plain English",
          "body": "Cloud services provide applications or computing resources through a provider rather than requiring every system to run in the customer’s office. SaaS delivers an application; IaaS provides infrastructure resources. The SDR needs the business context, not a platform-design discussion."
        },
        {
          "title": "Having Microsoft 365 is a starting point",
          "body": "Microsoft 365 provides productivity services and capabilities that depend on the plan and configuration. Someone still needs to manage users, permissions, settings, support, and change. Buying licenses does not by itself describe how those responsibilities are handled."
        },
        {
          "title": "Migration is a project",
          "body": "Moving email, files, or systems needs planning around access, dependencies, disruption, and responsibilities. Ongoing management after the move is another conversation. Discover a planned change and its business reason; leave architecture and validation to specialists."
        }
      ],
      "scene": "“We’re on Microsoft 365 already. Our finance manager still handles every new account and access issue.”",
      "questions": [
        {
          "prompt": "What opening is present?",
          "options": [
            {
              "text": "Administration and support ownership may be worth exploring.",
              "why": "Existing licenses do not tell you whether the operating process works well."
            },
            {
              "text": "There is no possible IT-support conversation because they have Microsoft 365.",
              "why": "Licensing and managed support are different."
            },
            {
              "text": "They must immediately migrate to a different cloud platform.",
              "why": "There is no evidence that a platform change is needed."
            }
          ],
          "answer": 0
        },
        {
          "prompt": "Which follow-up stays in the SDR’s lane?",
          "options": [
            {
              "text": "Send me administrator access so I can check your tenant.",
              "why": "Do not request privileged access in an outbound discovery conversation."
            },
            {
              "text": "Your current license is definitely wrong.",
              "why": "The license and requirements have not been assessed."
            },
            {
              "text": "How does that workload affect the finance manager’s other responsibilities?",
              "why": "Explore business impact without auditing permissions."
            }
          ],
          "answer": 2
        }
      ],
      "terms": [
        "cloud",
        "microsoft-365"
      ]
    },
    {
      "id": "continuity",
      "phase": "foundations",
      "title": "Backups and business continuity",
      "subtitle": "A copy of data and a workable recovery plan are different.",
      "cards": [
        {
          "title": "Backup and restore",
          "body": "A backup preserves copies for recovery. A restore is the process of recovering data or systems. A provider needs to understand what is protected, how often, where copies are kept, and how recovery is tested. An SDR should not request confidential configurations."
        },
        {
          "title": "Recovery expectations",
          "body": "Recovery Point Objective (RPO) concerns how much data loss is tolerable, expressed as a time window. Recovery Time Objective (RTO) concerns the target time to restore operations. You can ask which workflows must resume first and how long the business can reasonably operate without them; specialists validate technical targets."
        },
        {
          "title": "Continuity is a business conversation",
          "body": "Disaster recovery focuses on restoring technology. Business continuity includes how people keep essential work going during disruption. Internet loss, accidental deletion, hardware failure, and security incidents can all interrupt operations. Do not use a backup claim to promise zero downtime."
        }
      ],
      "scene": "“We back everything up. We have never actually tried restoring the scheduling system.”",
      "questions": [
        {
          "prompt": "Which follow-up is useful?",
          "options": [
            {
              "text": "Your backups are definitely broken.",
              "why": "No test evidence has been reviewed."
            },
            {
              "text": "A backup guarantees no interruption.",
              "why": "A backup does not prove recovery speed or business continuity."
            },
            {
              "text": "What would need to come back first, and who would coordinate the recovery?",
              "why": "This explores recovery priorities and ownership."
            }
          ],
          "answer": 2
        },
        {
          "prompt": "What is the practical difference between RPO and RTO?",
          "options": [
            {
              "text": "RPO guarantees no lost files and RTO guarantees instant recovery.",
              "why": "Objectives do not create unconditional guarantees."
            },
            {
              "text": "RPO is the tolerable data-loss window; RTO is the target restoration time.",
              "why": "These are different recovery requirements for a specialist to validate."
            },
            {
              "text": "Both mean the help desk will answer immediately.",
              "why": "They describe recovery objectives, not help-desk response."
            }
          ],
          "answer": 1
        }
      ],
      "terms": [
        "backup",
        "disaster-recovery"
      ]
    },
    {
      "id": "security",
      "phase": "foundations",
      "title": "Security as part of managed IT",
      "subtitle": "Acknowledge protection without promising immunity.",
      "cards": [
        {
          "title": "Security has several layers",
          "body": "Access controls, updates, endpoint protection, awareness, monitoring, backup, and response planning address different risks. Microsoft 365 and two-step verification can be valuable protections; their presence does not prove every risk or operational responsibility is covered."
        },
        {
          "title": "Business relevance before fear",
          "body": "Small organizations still depend on technology and data. Size alone does not establish immunity, but it also does not justify telling a particular prospect that an attack is inevitable. Explore their priorities, responsibilities, and any planning needs without using threats to pressure a meeting."
        },
        {
          "title": "Stay within approved scope",
          "body": "An MSP may offer security services itself or work with specialist partners. Do not claim guaranteed protection, declare a breach, or assess compliance from a short outbound conversation. The SDR can establish whether a scoped specialist discussion is welcome."
        }
      ],
      "scene": "“We use Microsoft 365 and two-step verification, so hackers cannot get us.”",
      "questions": [
        {
          "prompt": "Which response is proportionate?",
          "options": [
            {
              "text": "Then you are completely protected.",
              "why": "Those controls do not establish immunity."
            },
            {
              "text": "Those are useful controls. Who handles ongoing updates, support, and recovery planning around them?",
              "why": "Acknowledge the protection and explore responsibilities without arguing or diagnosing."
            },
            {
              "text": "You will definitely get hacked without our service.",
              "why": "That is an unsupported fear claim."
            }
          ],
          "answer": 1
        },
        {
          "prompt": "A small business says it is too small to be targeted. What is useful?",
          "options": [
            {
              "text": "Explore the systems it relies on and whether continuity or support is a current priority, if receptive.",
              "why": "Business relevance is more useful than a speculative threat."
            },
            {
              "text": "Describe a catastrophic attack as certain.",
              "why": "Certainty and pressure are not supported."
            },
            {
              "text": "Assume the business has no need for IT support.",
              "why": "Company size alone does not tell you its technology needs."
            }
          ],
          "answer": 0
        }
      ],
      "terms": [
        "mfa",
        "cybersecurity"
      ]
    },
    {
      "id": "business-value",
      "phase": "foundations",
      "title": "Translate services into business value",
      "subtitle": "Explain the outcome and the conditions.",
      "cards": [
        {
          "title": "Capacity and coordination",
          "body": "An MSP can provide a team and an agreed service process so a customer has less day-to-day staffing and vendor coordination to manage. The provider takes responsibility for its people and agreed execution. Scope, escalation routes, and accountability still need to be clear."
        },
        {
          "title": "Cost and coverage",
          "body": "Potential value can include more predictable spending, access to broader skills, or less management overhead. Savings and 24/7 live support depend on the actual offer and the customer’s baseline. Do not guarantee a lower bill or continuous coverage from the MSP label alone."
        },
        {
          "title": "Use the prospect’s words",
          "body": "If a manager spends Fridays chasing ticket updates, explore the time and ownership problem. If an internal IT team is planning a migration, explore capacity and priorities. Relate one approved capability to the stated situation instead of reciting a full service catalog."
        }
      ],
      "scene": "“Our IT manager is good, but vacations are difficult and projects stop whenever support requests pile up.”",
      "questions": [
        {
          "prompt": "What value is relevant to explore?",
          "options": [
            {
              "text": "Backup capacity and clearer coverage during absences, within the MSP’s approved scope.",
              "why": "This respects the internal team and follows the stated workload problem."
            },
            {
              "text": "Replacing the IT manager to save a guaranteed percentage.",
              "why": "Neither replacement nor savings is established."
            },
            {
              "text": "Selling AI because it is trending.",
              "why": "That does not address the signal provided."
            }
          ],
          "answer": 0
        },
        {
          "prompt": "Which statement is safe before scope and pricing are known?",
          "options": [
            {
              "text": "We will always cost less than your internal team.",
              "why": "A cost comparison has not been made."
            },
            {
              "text": "Every MSP includes unlimited 24/7 live support.",
              "why": "Coverage and limits vary by agreement."
            },
            {
              "text": "We can explore whether the service model reduces coordination burden and fits your support needs.",
              "why": "This describes an appropriate discovery purpose."
            }
          ],
          "answer": 2
        }
      ],
      "terms": []
    },
    {
      "id": "assessments",
      "phase": "foundations",
      "title": "Third-party assessments",
      "subtitle": "Earn interest through a clear, permission-based scope.",
      "cards": [
        {
          "title": "A reason for a second opinion",
          "body": "An assessment can help clarify the current environment, identify areas to investigate, or support planning. A trusted incumbent and a second opinion can coexist. Do not claim that every assessment will uncover weaknesses or require a provider change."
        },
        {
          "title": "Different reviews answer different questions",
          "body": "An IT review, security assessment, vulnerability scan, penetration test, and compliance review have different scopes. Do not use the labels interchangeably or promise testing the MSP has not approved. Access and testing require appropriate authorization."
        },
        {
          "title": "Confirm the offer",
          "body": "Know from your campaign brief whether the client’s assessment is paid or free before making the call—for example, Athens Micro only offers paid assessments. State the fee structure clearly, then sell why taking the discovery appointment is still worth their time to review scope and priorities."
        }
      ],
      "scene": "“If we do a third-party assessment, will you charge us?” Your campaign brief states this client only offers paid assessments.",
      "questions": [
        {
          "prompt": "What is the responsible next response?",
          "options": [
            {
              "text": "It is always free for qualified prospects.",
              "why": "Contradicts the campaign brief and misleads the prospect."
            },
            {
              "text": "Agree to begin scanning now and discuss costs later.",
              "why": "Neither access nor testing has been authorized."
            },
            {
              "text": "This client only offers paid assessments, and taking a 15-minute discovery appointment lets you confirm whether the scope and ROI justify that investment before committing.",
              "why": "State upfront whether the assessment is paid or free, then sell why taking the appointment is valuable."
            }
          ],
          "answer": 2
        },
        {
          "prompt": "They like their long-standing provider but welcome a planning review. What is a sound purpose?",
          "options": [
            {
              "text": "Treat the meeting as consent to a penetration test.",
              "why": "Meeting consent does not authorize technical testing."
            },
            {
              "text": "A scoped second opinion that supports planning without assuming replacement.",
              "why": "Interest can exist without a declared incident or intent to change providers."
            },
            {
              "text": "Prove their provider is failing.",
              "why": "That accusation is not supported."
            }
          ],
          "answer": 1
        }
      ],
      "terms": [
        "third-party-assessment"
      ]
    },
    {
      "id": "discovery",
      "phase": "conversation",
      "title": "Use the answer you just earned",
      "subtitle": "Setup → signal → impact → purpose.",
      "cards": [
        {
          "title": "Understand the starting point",
          "body": "Ask how IT is supported now: internal staff, an external provider, a mixed model, or ad hoc help. Adapt your next question to the answer. A series of unrelated qualifying questions can feel like an interrogation."
        },
        {
          "title": "Follow the signal",
          "body": "A new location, expiring agreement, overloaded team, delayed new hires, or upcoming migration can be relevant. Ask what will change, how it is handled now, or what impact it has. One useful follow-up is better than returning immediately to a generic pitch."
        },
        {
          "title": "Give discovery a purpose",
          "body": "Use the confirmed information to explain why another conversation may help. Interest in planning or a second opinion can be enough; do not manufacture pain. Confirm who should attend and what they expect to cover."
        }
      ],
      "scene": "“Our provider is fine. We are acquiring another company in February, though.”",
      "questions": [
        {
          "prompt": "Which question follows the signal?",
          "options": [
            {
              "text": "Would you like to hear our entire services list?",
              "why": "That loses the specific signal."
            },
            {
              "text": "How are you planning to bring the two companies’ systems and support together?",
              "why": "It follows the announced change without assuming dissatisfaction."
            },
            {
              "text": "So what is your budget for replacing the provider?",
              "why": "Replacement and budget have not been raised."
            }
          ],
          "answer": 1
        },
        {
          "prompt": "When is discovery purposeful?",
          "options": [
            {
              "text": "When the contact welcomes a specific discussion tied to a need, plan, or second opinion.",
              "why": "A useful purpose can exist without declared pain."
            },
            {
              "text": "Only after the SDR proves a technical weakness.",
              "why": "Technical proof is outside this call’s scope and is not always necessary."
            },
            {
              "text": "Whenever someone agrees to receive an email.",
              "why": "Email permission does not establish a meeting purpose."
            }
          ],
          "answer": 0
        }
      ],
      "terms": []
    },
    {
      "id": "stakeholders",
      "phase": "conversation",
      "title": "People, authority, and gatekeepers",
      "subtitle": "Find a legitimate route.",
      "cards": [
        {
          "title": "Different people see different effects",
          "body": "Owners may focus on business continuity and management burden. Office managers may see onboarding and daily support issues. IT leaders may focus on capacity and ownership. Corporate may control vendor selection. These are starting hypotheses, not facts about an individual."
        },
        {
          "title": "An outdated contact is new information",
          "body": "If the named director left, acknowledge the correction and ask who now owns that responsibility, if appropriate. Do not invent a personal connection or imply the former employee referred you. Record the change for follow-up."
        },
        {
          "title": "Respect routing limits",
          "body": "A general corporate email or an offer to pass a message may be the available route. Ask what information helps routing. A gatekeeper cannot confirm a meeting for an absent decision-maker unless they actually have that authority."
        }
      ],
      "scene": "“That director left. Corporate handles this, and we can only give you the general email.”",
      "questions": [
        {
          "prompt": "What is the useful move?",
          "options": [
            {
              "text": "Thank them for the correction and confirm the permitted address and routing subject.",
              "why": "Use the route they can legitimately provide."
            },
            {
              "text": "Insist on a personal mobile number.",
              "why": "That ignores their stated boundary."
            },
            {
              "text": "Say the former director recommended you.",
              "why": "No referral has been provided."
            }
          ],
          "answer": 0
        },
        {
          "prompt": "“Leave a message and I will pass it to my boss.” What is confirmed?",
          "options": [
            {
              "text": "A discovery appointment with the boss.",
              "why": "Forwarding a message is not acceptance."
            },
            {
              "text": "Permission to call the boss through any channel.",
              "why": "The contact has offered a limited action."
            },
            {
              "text": "A message handoff, with any additional follow-up only if agreed.",
              "why": "The boss has not personally accepted a conversation."
            }
          ],
          "answer": 2
        }
      ],
      "terms": []
    },
    {
      "id": "next-steps",
      "phase": "conversation",
      "title": "Close the next step clearly",
      "subtitle": "Email, vacation, contracts, and the discovery Call to Action (CTA).",
      "cards": [
        {
          "title": "Send me an email",
          "body": "If the person is receptive, clarify what would be useful and whether a follow-up is welcome. Confirm the actual address or approved route. If they accept only the email and will respond if interested, honor that limit; a callback is not automatically agreed."
        },
        {
          "title": "Vacation and callback",
          "body": "When told the boss is on vacation, ask for a reasonable return or contact window if welcome. A callback is a reconnection, not a discovery appointment. Record who suggested it, the channel, and the purpose; do not invent a calendar commitment."
        },
        {
          "title": "Contract and timing",
          "body": "An active contract may limit present options, but a future review window can still be relevant. Ask when planning normally happens if they welcome the question. Contract expiration and vendor-review timing are different. A firm refusal ends the pitch even when a contract date is known."
        }
      ],
      "scene": "“We have a contract through December. Send a short email in September; we usually start planning then.”",
      "questions": [
        {
          "prompt": "Which close follows the evidence?",
          "options": [
            {
              "text": "Book a discovery call next week automatically.",
              "why": "No immediate meeting has been accepted."
            },
            {
              "text": "Wait until December because contracts cannot be discussed sooner.",
              "why": "They identified a planning window before expiry."
            },
            {
              "text": "Confirm the September email, its planning purpose, and whether any later follow-up is welcome.",
              "why": "Use the review window and permitted channel."
            }
          ],
          "answer": 2
        },
        {
          "prompt": "“Email only. We will reply if interested.” What should you do?",
          "options": [
            {
              "text": "Treat the email as a booked appointment.",
              "why": "There is no meeting commitment."
            },
            {
              "text": "Send only the agreed information and record the restriction.",
              "why": "They have explicitly limited the next step."
            },
            {
              "text": "Schedule weekly calls because email permission implies follow-up.",
              "why": "Permission is channel- and purpose-specific."
            }
          ],
          "answer": 1
        }
      ],
      "terms": []
    },
    {
      "id": "boundaries",
      "phase": "conversation",
      "title": "Persist with judgment. Protect the relationship.",
      "subtitle": "Clarify when there is room; stop when the limit is clear.",
      "cards": [
        {
          "title": "A useful clarification",
          "body": "A neutral “we are covered” may leave room for one relevant question, depending on tone and context. Acknowledge the current setup and explore a specific gap or plan. There is no required number of rebuttals and no need to challenge every objection."
        },
        {
          "title": "Recognize the end",
          "body": "A repeated firm refusal ends the pitch. An explicit request to stop contact requires the appropriate suppression or exclusion handling. Do not move to email, another person, or a different channel to evade that restriction."
        },
        {
          "title": "Nurture, recycle, close, exclude",
          "body": "Nurture has a welcomed future purpose or follow-up. Recycle means internal reassessment under approved rules; it creates no new permission. Close when there is no viable opportunity. Exclude when a contact restriction requires it. Use the actual evidence rather than avoiding an unfavorable disposition."
        }
      ],
      "scene": "After a brief clarification, the prospect says: “No. Stop calling and emailing this company.”",
      "questions": [
        {
          "prompt": "What action is required?",
          "options": [
            {
              "text": "Call a colleague at the same company to work around it.",
              "why": "That evades the stated restriction."
            },
            {
              "text": "Acknowledge, end the pitch, and record the company-level no-contact request through the approved process.",
              "why": "The explicit scope includes calls and email to the company."
            },
            {
              "text": "Move the lead to nurture and email in a month.",
              "why": "Nurture does not override a no-contact request."
            }
          ],
          "answer": 1
        },
        {
          "prompt": "When is recycle reasonable?",
          "options": [
            {
              "text": "When internal reassessment is appropriate and no restriction is being bypassed.",
              "why": "Recycle is an internal handling decision, not consent."
            },
            {
              "text": "Whenever the prospect asks to be removed.",
              "why": "That requires exclusion handling, not recycling."
            },
            {
              "text": "Whenever the SDR wants to avoid recording a firm refusal.",
              "why": "The disposition should reflect the evidence."
            }
          ],
          "answer": 0
        }
      ],
      "terms": []
    },
    {
      "id": "listening-lab",
      "phase": "application",
      "title": "Listen for the missed opportunity",
      "subtitle": "Practice a follow-up before the pitch.",
      "cards": [
        {
          "title": "Read the conversation",
          "body": "Prospect: “We have an internal team. They are supporting 70 people and opening a second site in March.” SDR: “Great. We offer cybersecurity, cloud, and IT support. Could we meet Tuesday?”"
        },
        {
          "title": "What was available",
          "body": "The contact provided a support model, scale, and a planned change. The next question should explore how that change affects capacity, onboarding, coverage, or project ownership. The statement does not prove dissatisfaction."
        },
        {
          "title": "Apply it",
          "body": "After the knowledge check, complete “Follow the signal” in Applied practice. Write the actual follow-up questions you would ask and explain which information would make discovery useful. Avoid turning every question into a disguised pitch."
        }
      ],
      "scene": "You can ask one natural question before describing services.",
      "questions": [
        {
          "prompt": "Which question earns more useful context?",
          "options": [
            {
              "text": "How is your team planning to cover the new site alongside its current support workload?",
              "why": "It connects the change with capacity and invites a real answer."
            },
            {
              "text": "Are you ready to replace your internal team?",
              "why": "No replacement interest was stated."
            },
            {
              "text": "Would you like our cybersecurity brochure?",
              "why": "That does not follow the expansion signal."
            }
          ],
          "answer": 0
        },
        {
          "prompt": "What should you avoid putting in your notes?",
          "options": [
            {
              "text": "The second site is planned for March.",
              "why": "That is stated information."
            },
            {
              "text": "The internal team currently supports 70 people.",
              "why": "That is also stated information."
            },
            {
              "text": "“Their internal IT is failing” when the contact only described the expansion.",
              "why": "A plan and workload are confirmed; failure is an unsupported conclusion."
            }
          ],
          "answer": 2
        }
      ],
      "terms": []
    },
    {
      "id": "handoff-lab",
      "phase": "application",
      "title": "Make your handoff usable",
      "subtitle": "Facts, unknowns, and the actual agreement.",
      "cards": [
        {
          "title": "Read the conversation",
          "body": "Prospect: “We have 42 employees and an internal IT lead. Onboarding has taken several days lately. Our operations director wants to review the process next month. Email me an outline today; I can check whether she wants a discovery conversation. No callback yet.”"
        },
        {
          "title": "Record what is known",
          "body": "Capture the current support model, the onboarding delay as reported, the director’s involvement, and the planning window. Separate the contact’s words from your interpretation. Identify the exact send commitment and the explicit callback restriction."
        },
        {
          "title": "Do not manufacture a win",
          "body": "The director has not agreed to a meeting. No cost, technical cause, or replacement decision is known. A useful handoff tells the next person what to validate and what they must not assume. Practice using fictional details only."
        }
      ],
      "scene": "Your Customer Relationship Management (CRM) disposition must match what the contact actually accepted.",
      "questions": [
        {
          "prompt": "Which next-step note is accurate?",
          "options": [
            {
              "text": "Discovery booked next month with the director.",
              "why": "The director has not accepted."
            },
            {
              "text": "Call tomorrow to confirm the director’s availability.",
              "why": "The contact explicitly said no callback yet."
            },
            {
              "text": "Send the outline today; contact will check the director’s interest. No callback is agreed.",
              "why": "The email handoff and restriction are explicit."
            }
          ],
          "answer": 2
        },
        {
          "prompt": "Which item belongs in “unknowns”?",
          "options": [
            {
              "text": "The company has an internal IT lead.",
              "why": "The contact also stated that fact."
            },
            {
              "text": "Whether the director wants discovery and what causes the onboarding delay.",
              "why": "Neither has been confirmed."
            },
            {
              "text": "The company has 42 employees.",
              "why": "The contact stated that fact."
            }
          ],
          "answer": 1
        }
      ],
      "terms": []
    },
    {
      "id": "readiness",
      "phase": "readiness",
      "title": "Put the pieces together",
      "subtitle": "New situations. Your next move. Your reasoning.",
      "cards": [
        {
          "title": "Complete your evidence",
          "body": "Finish the knowledge checks and applied submissions. Practice at least six distinct main-case responses and complete one full Call Lab conversation. You may use the wider 85-case bank at any time; opening a case does not count as submitting it."
        },
        {
          "title": "Know the assigned account",
          "body": "Your administrator supplies a client brief with approved services, territory, coverage, assessment terms, and handoff requirements. Complete the client-brief exercise against that version. Missing account details are questions to resolve, not permission to invent an offer."
        },
        {
          "title": "Readiness is reviewed",
          "body": "Meeting the submission requirements makes your work available for review. A training administrator reviews the evidence and can request focused practice or mark you ready for supervised calls. This is training readiness; it is not a technical certification or proof of live-call performance."
        }
      ],
      "scene": "Choose the next move in six different situations. First attempts remain visible, and retries can show improvement.",
      "questions": [
        {
          "prompt": "A 15-person company has no security concerns but loses an hour whenever its shipping software stops. Where do you begin?",
          "options": [
            {
              "text": "Promise a one-hour fix.",
              "why": "No cause, scope, or resolution commitment is known."
            },
            {
              "text": "Ask how interruptions are handled and what the delay affects.",
              "why": "Follow the operational issue without diagnosing the software."
            },
            {
              "text": "Insist that ransomware is their only important risk.",
              "why": "Their stated issue concerns interrupted shipping."
            }
          ],
          "answer": 1
        },
        {
          "prompt": "An internal IT manager says, “We do not want co-management.” What is reasonable if their tone is open?",
          "options": [
            {
              "text": "Acknowledge that preference and ask whether any standalone approved project or support need is relevant.",
              "why": "Explore a real alternative only if the assigned MSP offers it and the contact is receptive."
            },
            {
              "text": "Keep renaming co-management until they agree.",
              "why": "Changing labels does not respect their objection."
            },
            {
              "text": "Assume every project is automatically in scope.",
              "why": "An approved client portfolio is still required."
            }
          ],
          "answer": 0
        },
        {
          "prompt": "A trusted provider has worked with them for ten years without an incident. They are curious about planning a cloud move. What purpose could discovery have?",
          "options": [
            {
              "text": "Tell them ten years guarantees a hidden breach.",
              "why": "That is unsupported."
            },
            {
              "text": "Say no incident means no possible business conversation.",
              "why": "A planned change can still be relevant."
            },
            {
              "text": "Explore the planned move and whether a second opinion would help.",
              "why": "A welcomed plan can create relevance without attacking the incumbent."
            }
          ],
          "answer": 2
        },
        {
          "prompt": "“We are not interested in AI.” Your brief includes everyday help-desk services. What should guide the response?",
          "options": [
            {
              "text": "Claim every help-desk task is an AI service.",
              "why": "That misrepresents the offer."
            },
            {
              "text": "Acknowledge it; clarify your relevant IT-support purpose briefly if the person remains receptive.",
              "why": "The conversation should match approved services and the contact’s interest."
            },
            {
              "text": "Argue that every business must buy AI.",
              "why": "That ignores the stated preference and the actual purpose."
            }
          ],
          "answer": 1
        },
        {
          "prompt": "“Who gave you my number?” What is the next move?",
          "options": [
            {
              "text": "Explain the verified source or your uncertainty honestly and follow the approved preference-handling process.",
              "why": "Do not invent a referral or dodge a contact preference."
            },
            {
              "text": "Claim a colleague referred you without evidence.",
              "why": "That fabricates provenance."
            },
            {
              "text": "Ignore the question and finish the pitch.",
              "why": "The contact has asked about the legitimacy of the outreach."
            }
          ],
          "answer": 0
        },
        {
          "prompt": "After a focused clarification, the person firmly repeats, “We are not interested.” No future purpose is offered. What should you do?",
          "options": [
            {
              "text": "Require two more objections before stopping.",
              "why": "There is no rebuttal quota."
            },
            {
              "text": "Record an agreed callback anyway.",
              "why": "No callback was accepted."
            },
            {
              "text": "End courteously and document the actual outcome and any contact restriction.",
              "why": "There is no remaining opening that justifies another rebuttal."
            }
          ],
          "answer": 2
        }
      ],
      "terms": []
    }
  ],
  "PHASES": [
    {
      "id": "orientation",
      "name": "Welcome & your role",
      "description": "Know who you represent and what the SDR owns."
    },
    {
      "id": "foundations",
      "name": "MSP Foundations",
      "description": "Understand IT services, delivery, and business value."
    },
    {
      "id": "conversation",
      "name": "Conversation skills",
      "description": "Discover, position, agree, and recognize the limit."
    },
    {
      "id": "application",
      "name": "Applied practice",
      "description": "Use a signal and write a usable handoff."
    },
    {
      "id": "readiness",
      "name": "Readiness review",
      "description": "Bring your knowledge, practice, and account brief together."
    }
  ],
  "TASKS": [
    {
      "id": "explain-msp",
      "phase": "foundations",
      "title": "Explain an MSP in your own words",
      "context": "A business owner has never used a managed IT provider. Explain the model without giving a technical lecture or an unapproved guarantee.",
      "fields": [
        {
          "id": "meaning",
          "label": "Plain-English explanation",
          "prompt": "What does an MSP take responsibility for, and how is the agreement important?",
          "min": 100,
          "max": 2200
        },
        {
          "id": "value",
          "label": "Two business benefits",
          "prompt": "Use a practical support, cloud, or coordination example. Explain the conditions behind the benefit.",
          "min": 100,
          "max": 2200
        },
        {
          "id": "limits",
          "label": "Keep the promise honest",
          "prompt": "What would you need to confirm before discussing 24/7 coverage, savings, or assessment terms?",
          "min": 80,
          "max": 2200
        }
      ]
    },
    {
      "id": "follow-signal",
      "phase": "application",
      "title": "Follow the signal",
      "context": "“We have an internal team. They support 70 people and are opening a second site in March.” No dissatisfaction or buying decision has been stated.",
      "fields": [
        {
          "id": "first",
          "label": "Your first follow-up",
          "prompt": "Write the actual question you would ask about the expansion.",
          "min": 30,
          "max": 2200
        },
        {
          "id": "second",
          "label": "Use the next answer",
          "prompt": "They reply: “The same two people will cover both sites, and onboarding already takes a few days.” Write your next question.",
          "min": 30,
          "max": 2200
        },
        {
          "id": "purpose",
          "label": "A relevant discovery purpose",
          "prompt": "Explain what you would confirm before proposing a discovery call.",
          "min": 70,
          "max": 2200
        }
      ]
    },
    {
      "id": "handoff",
      "phase": "application",
      "title": "Write the CRM handoff",
      "context": "“We have 42 employees and an internal IT lead. Onboarding has taken several days lately. Our operations director wants to review the process next month. Email me an outline today; I can check whether she wants discovery. No callback yet.”",
      "fields": [
        {
          "id": "facts",
          "label": "Confirmed facts",
          "prompt": "Capture the current setup, reported issue, people, and timing.",
          "min": 100,
          "max": 2200
        },
        {
          "id": "unknowns",
          "label": "What still needs validation",
          "prompt": "Separate unknowns from assumptions about budget, cause, authority, or replacement.",
          "min": 60,
          "max": 2200
        },
        {
          "id": "agreement",
          "label": "Disposition and exact next step",
          "prompt": "Record what you will send, what is not agreed, and the contact restriction.",
          "min": 80,
          "max": 2200
        }
      ]
    },
    {
      "id": "client-brief",
      "phase": "readiness",
      "title": "Know your assigned MSP",
      "context": "Use the administrator-approved brief below. If it is missing or incomplete, request clarification. Do not fill gaps using another MSP’s offer.",
      "requiresBrief": true,
      "fields": [
        {
          "id": "positioning",
          "label": "Your approved introduction",
          "prompt": "Introduce the assigned MSP and a relevant service in natural outbound language.",
          "min": 70,
          "max": 2200
        },
        {
          "id": "question",
          "label": "A discovery question",
          "prompt": "Choose a question that fits the approved services and customer profile.",
          "min": 35,
          "max": 2200
        },
        {
          "id": "boundaries",
          "label": "Promises and handoff",
          "prompt": "State the confirmed coverage and assessment terms, and what you must route to a specialist.",
          "min": 90,
          "max": 2200
        }
      ]
    },
    {
      "id": "reflection",
      "phase": "readiness",
      "title": "Explain your next-call judgment",
      "context": "Use your practice decisions. Your administrator will read this explanation alongside the recorded checks, cases, and full-call evidence.",
      "fields": [
        {
          "id": "strength",
          "label": "A behavior you can repeat",
          "prompt": "Describe a specific useful behavior and when you would use it.",
          "min": 80,
          "max": 2200
        },
        {
          "id": "stop",
          "label": "A boundary you can recognize",
          "prompt": "Give an example of when to stop, nurture, recycle, or exclude. Explain the distinction.",
          "min": 100,
          "max": 2200
        },
        {
          "id": "focus",
          "label": "Your next practice focus",
          "prompt": "Name a remaining uncertainty and the exact behavior you will practice.",
          "min": 70,
          "max": 2200
        }
      ]
    }
  ],
  "SOURCES": [
    {
      "title": "OSR Manage — services and purpose",
      "url": "https://osrmanage.com/"
    },
    {
      "title": "GSD Staffing — company overview",
      "url": "https://gsdstaffing.com/about/"
    },
    {
      "title": "IBM — managed services, help desk, and cloud",
      "url": "https://www.ibm.com/consulting/technology"
    },
    {
      "title": "CISA — risk considerations for MSP customers",
      "url": "https://www.cisa.gov/sites/default/files/publications/cisa-insights_risk-considerations-for-msp-customers_508.pdf"
    }
  ]
};
if(typeof module!=='undefined')module.exports=ONBOARDING;
